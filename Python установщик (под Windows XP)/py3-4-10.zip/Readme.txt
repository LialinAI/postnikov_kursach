This is an unofficial Python 3.4.10 installation package for Windows, compiled by Matej Horvat.

http://matejhorvat.si/en/windows/python/

The installation will fail unless you uncheck the option to install pip. Instead, install it manually later by running python.exe as an administrator in this directory with the parameters:

get-pip.py --no-index --find-links=.

If you get an error about MSVCR100.dll missing, run vcredist_x86.exe to install it.